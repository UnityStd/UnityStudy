﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private Text scoreP;


    void Start()
    {
        
    }

    void Update()
    {

    }
}
