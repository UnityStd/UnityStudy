﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name == "Ball")
        {
            col.gameObject.transform.position = new Vector3(0, 1f, -3);
            col.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
    }
    
    void Start()
    {

    }
    void Update()
    {

    }
}
